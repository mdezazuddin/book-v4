<?php $page= "product";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- section1 -->
        <section class="section1 bg-sec4">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container py-5">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white">Products</h1>
                        <p class="mt-3 small">
                            <a class="clr-red mr-2 text-white text-decoration-none small" href="index.php">Home</a> 
                            <span class="text-white small"> / &nbsp; Products</span>
                        </p>
                    </div>
                </div>
            </div>
        </section><br>

        
        <!-- section1-of-blog -->
        <section class="section1-of-blog mt-5 pt-2">
            <div class="col-md-11 mx-auto">
                <div class="row">
                    <div class="sec1-of-blog col-lg-3">
                        <div class="card border-0">
                            <div class="input-group">
                                <input type="text" class="form-control p-4 rounded-0 shadow-none" placeholder="Search">
                                <div class="input-group-append">
                                    <button class="btn btn btns9 px-4 rounded-0" type="button"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                            <div class="card-body py-3 bg-blue1 mt-5">
                                <h6 class="mb-0 text-white font-weight-normal">CATEGORIES</h6>
                            </div>
                            <div class="navs7 mt-5">
                                <a class="th2 nav-link p-0 mb-0" href="#" data-toggle="collapse" data-target="#demo">
                                    <div class="d-flex justify-content-between">
                                        <span><i class="fa fa-chevron-right fnts1 mr-2"></i> Baby Needs (6)</span>
                                        <i class="fa fa-chevron-right fnts1 mt-2"></i>
                                    </div>
                                </a>
                                <div id="demo" class="collapse">
                                    <div class="card-body py-1">
                                        <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-chevron-right fnts1  mr-2"></i> Wooden Flooring</a>
                                        <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-chevron-right fnts1  mr-2"></i> Artificial Grass Flooring</a>
                                        <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-chevron-right fnts1  mr-2"></i> Tiles & Marble Works</a>
                                    </div>
                                </div>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-chevron-right fnts1  mr-2"></i> Wooden Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-chevron-right fnts1  mr-2"></i> Artificial Grass Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-chevron-right fnts1  mr-2"></i> Tiles & Marble Works</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-chevron-right fnts1  mr-2"></i> Artificial Grass Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-chevron-right fnts1  mr-2"></i> Tiles & Marble Works</a>
                            </div>

                            <div class="card-body py-3 bg-blue1 mt-5">
                                <h6 class="mb-0 text-white font-weight-normal">RECENT POSTS</h6>
                            </div>
                            <div class="mt-4">
                                <form action="/action_page.php">
                                    <label class="text-grey" for="customRange">Range : $30 - $815</label>
                                    <input type="range" class="custom-range" id="customRange" name="points1">
                                </form>
                            </div>

                            <div class="card-body py-3 bg-blue1 mt-5">
                                <h6 class="mb-0 text-white font-weight-normal">CAPACITY</h6>
                            </div>
                            <div class="navs7 mt-4">
                                <a class="th2 nav-link p-0" href=""><i class="fa fa-square-o mt-4 mr-2"></i> Texture Painting</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Wooden Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Artificial Grass Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Tiles & Marble Works</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Artificial Grass Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Tiles & Marble Works</a>
                            </div>
                            <div class="card-body py-3 bg-blue1 mt-5">
                                <h6 class="mb-0 text-white font-weight-normal">BRANDS</h6>
                            </div>
                            <div class="navs7 mt-4">
                                <a class="th2 nav-link p-0" href=""><i class="fa fa-square-o mt-4 mr-2"></i> Texture Painting</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Wooden Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Artificial Grass Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Tiles & Marble Works</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Artificial Grass Flooring</a>
                                <a class="th2 nav-link p-0 mt-4" href=""><i class="fa fa-square-o mr-2"></i> Tiles & Marble Works</a>
                            </div>
                            
                            <div class="card-body py-3 bg-blue1 mt-5">
                                <h6 class="mb-0 text-white font-weight-normal">TAGS</h6>
                            </div>
                            <div class="mt-5">
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Baby Needs</button>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Capsuls</button><br>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Health</button>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Fitnes</button>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Baby Needs</button>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Capsuls</button><br>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Health</button>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Fitnes</button>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Baby Needs</button>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Capsuls</button><br>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Health</button>
                                <button type="submit" class="btns9 btn btn rounded-0 mb-3 mr-sm-2 bd3">Fitnes</button>
                            </div>
                        </div>
                    </div>



                    <div class="sec1-of-blog col-lg-9">
                        <div class="d-md-flex justify-content-between">
                            <div class="mt-3">
                                <a class="text-hvr1 text-decoration-none" href="#"><i class="fa fa-table fa-lg"></i></a>
                                <a class="text-hvr1 text-decoration-none ml-2" href="#"><i class="fa fa-table fa-lg"></i></a>
                                <a class="text-hvr1 text-decoration-none ml-2" href="#"><i class="fa fa-table fa-lg"></i></a>
                            </div>
                            
                            <div class="form-inline">
                                <form class="">
                                    <select name="cars" class="custom-select mt-3 rounded-0 font-weight-bold">
                                        <option selected>12</option>
                                        <option value="volvo">11</option>
                                        <option value="fiat">13</option>
                                        <option value="audi">14</option>
                                    </select>
                                    <select name="cars" class="custom-select mt-3 ml-md-4 rounded-0 font-weight-bold">
                                        <option selected>Default Sorting</option>
                                        <option value="volvo">Volvo</option>
                                        <option value="fiat">Fiat</option>
                                        <option value="audi">Audi</option>
                                    </select>
                                </form>
                            </div>
                        </div>
                    
                        <div class="row pl-md-4">
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book1.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book2.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book3.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book1.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book2.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book3.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book1.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book2.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book3.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book1.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book2.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-12 col-lg-4 mt-5 con4 left-reveal">
                                <div class="hvr-float-shadow con4">
                                    <a class="text-decoration-none" href="product_details.php">
                                        <img class="w-100 hvr-grow" src="assets/image/book3.png">
                                    </a>
                                    <div class="mt-4">
                                        <a class="text-hvr1 text-decoration-none" href="#"><h6 class="h5 mb-2">Kesab Barun</h6></a>
                                        <a class="text-hvr1 text-muted text-decoration-none" href="#"><h6 class="h6 small">Indian Clasic Vocal</h6></a>
                                        <hr>
                                        <div class="d-flex justify-content-between">
                                            <div class="con4">
                                                <span>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star text-grey1"></i>
                                                    <i class="fa fa-star-o text-grey1"></i>
                                                </span>
                                                <h6 class="text-gold mt-3">$30.00 - $46.00</h6>

                                                <div class="overlay4 bg-white">
                                                    <div class="text4 d-flex mt-2 pt-2">
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-eye"></i></a></span>
                                                        <span><a href="#" class="btn btn-outline-light btn-sm mt-3 rounded-0 ml-1 border btns8"><i class="fa fa-heart-o"></i></a></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="mr-5"><a href="#" class="btn btn-outline-light btns9 rounded-0 text-muted mt-3 px-2 pt-1 border"><i class="fa fa-arrow-right fa-lg"></i></a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 text-center">
                                <ul class="pagination justify-content-center mt-5 pt-3" style="margin:20px 0">
                                    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> <br><br>
        <hr>

        <section class="white-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 mt-3">
                        <h5 class="mt-5">ITEMS 1 TO 12 OF 12 TOTAL</h5>
                        <hr class="mt-2 mb-3">
                        <h4>QUIRKY JRS FIRST BY COOLWINKS SUNGLASSES</h4>
                        <hr class="my-2">
                        <p>Summer is almost here and it is time to shop this season’s trending sunglasses to protect your eyes and stay in style. Because you know, your armory is incomplete without the perfect summer shades. So, head online and start browsing the catalog of trendy sunglasses at Coolwinks. From top designs to refreshing colors and prints, unbeatable prices and great quality, you will find everything in the collection of JRS First by Coolwinks sunglasses.</p>
                        <h4 class="mt-4">JRS First by Coolwinks Sunglasses Styles for Men</h4>
                        <p>JRS First by Coolwinks sunglasses for men are offering adorable designs that make more stylish. It is also famous for summer shades and available with 100% uv protection. Men can shop in various styles like Clubmaster, oval shaped, wrap around, round shaped, pilot and retro square sunshades.</p>
                        <h4 class="mt-4">JRS First by Coolwinks Sunglasses Styles for Women</h4>
                        <p>JRS First by Coolwinks sunglasses for women are most preferable that comes in various colours like green, blue, orange, purple, black, red, and graphite. For women, there are various sunglasses frames type such as cat-eye, butterfly, retro square and pilot.<br><br>For every face shape, there is a style. Colors are unique and you will fall in love with the patterns. The trending tortoise-shell pattern and abstract pattern are also available here.<br><br>So, explore shop and look sharp with the most stylish pieces in eyewear.</p>
                        <h4 class="mt-4">Find a Wide Range of JRS First by Coolwinks Sunglasses</h4>
                        <p>Coolwinks is an online shopping site that believes in pampering its customers through loads of choices. Therefore, you will find many other sunglasses. Apart from shopping amazing JRS First by Coolwinks sunglasses.<br><br>Every range will offer you something new in terms of design and looks, ensuring you look your best every-time you step out.</p>
                        <h4 class="mt-4">Online Shopping in India with Coolwinks</h4>
                        <p>Indulge in shopping in India with this fashion online e-store and you will feel the difference. It is a one-stop shop selling eyewear products for everyone, at unmatched prices and the merchandise is 100% genuine. Where else, you will find all this.<br><br>Moreover, if you are looking to buy power sunglasses for yourself, then you are at the right place that offers you with plenty of choices in frames and styles.<br><br>In addition, you can pay online or by cash on delivery and returns and exchange are hassle-free. So, come online and start splurging before the latest sunglasses are gone.</p>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>    

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

</body>
</html>