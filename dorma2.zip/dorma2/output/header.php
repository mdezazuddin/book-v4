
	<nav class="navbar navbar-expand-lg p-md-0 nav1">
		<div class="container">
			<a class="navbar-brand clr-red pt-2 d-flex" href="index.php">
				<img src="assets/image/logo.png">
				<span class="font-weight-bold h4 ml-1 clr1 text-whites align-self-center">Dorma</span>
			</a>
			<button class="navbar-toggler navbar-dark clr2" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link clr1 <?php if($page=="home"){echo "active-menu";} ?>" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link clr1 <?php if($page=="about"){echo "active-menu";} ?>" href="about.php">About</a>
					</li>
					<li class="nav-item">
							<a class="nav-link clr1 dropdown-toggle <?php if($page=="ebooks"){echo "active-menu";} ?>" href="ebooks.php">Get Your Course</a>
							<ul class="shadow-sm rounded-lg">
								<li>
									<a href="about.php">Life Skill</a>
								</li>
								<li>
									<a href="about.php">Celebrity School</a>
								</li>
								<li>
									<a href="about.php">Dance</a>
								</li>
								<li>
									<a href="about.php">Music</a>
								</li>
								<li>
									<a href="about.php">Language</a>
								</li>
							</ul>
						</li> 
					<li class="nav-item">
						<a class="nav-link clr1 <?php if($page=="product"){echo "active-menu";} ?>"
							href="product.php">Product</a>
					</li>
					<li class="nav-item">
						<a class="nav-link clr1 <?php if($page=="contact"){echo "active-menu";} ?>" href="contact.php">Contact</a>
					</li>  
					<span class="pt-2"><a href="login.php" class="btn btn btns9 rounded-pill px-4 mt-2 ml-lg-4">Login</a></span>
					<span class="pt-2"><a href="register.php" class="btn btn btns9 rounded-pill px-4 mt-2 ml-lg-3">Register</a></span>
					<span class="pt-1"><a href="#" class="btn btn btns9 rounded-circle text-white ml-lg-3 mt-3 align-self-end px-2 py-1" data-toggle="modal" data-target="#myModal"><i class="fa fa-search"></i></a></span>
				</ul>
			</div>  
		</div>
	</nav>


	<!-- The Modal -->
    <div class="modal fade" id="myModal">
      <button type="button" class="close text-white mt-3 mr-4" data-dismiss="modal">&times;</button>
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-pill">
          <!-- Modal body -->
          <div class="modal-body btn-group rounded-pill p-0 bg-white">
              <span><i class="fa fa-search fa-lg text-muted ml-4 mt-4 pt-1 mr-3"></i></span>
              <input class="form-controll w-100 rounded border-0 p-4" type="text" name="name" placeholder="Search">
              <button type="button" class="btn btn text-white btns8 rounded-pill px-5"><b>Submit</b></button>
          </div>
        </div>
      </div>
    </div>