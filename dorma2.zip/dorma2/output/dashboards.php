<?php $page= "dashboard";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- section1 -->
        <section class="section1 bg-sec4">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container py-5">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white">My Account</h1>
                        <p class="mt-3 small">
                            <a class="clr-red mr-2 text-white text-decoration-none small" href="index.php">Home</a> 
                            <span class="text-white small"> / &nbsp; My Account</span>
                        </p>
                    </div>
                </div>
            </div>
        </section>

        
        <!-- section1-of-blog -->
        <section class="section1-of-blog py-5">
            <div class="container">
                <div class="row">
                    <div class="sec1-of-blog col-lg-3">
                        <div class="card border-0 rounded-0 shd1">
                            <div class="shd1 p-3">
                                <div class='d-flex'>
                                    <span class="w-25 mr-3"><img class="w-100 rounded-circle" src="assets/image/1.jpg"></span>
                                    <span class="align-self-center">
                                        <h6 class="font-weight-normal small">HELLO,</h6>
                                        <h6 class="text-gold small">MD EZAZ</h6>
                                    </span>
                                </div>
                            </div>
                            <div class="navs9 mt-4">
                                <!-- Nav pills -->
                                <ul class="nav nav-pills flex-column ezaz" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active rounded-0" data-toggle="pill" href="#home"><i class="fa fa-user mr-2"></i> Personal Information</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link rounded-0" data-toggle="pill" href="#menu1"><i class="fa fa-lock mr-2"></i> Change Password</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link rounded-0" data-toggle="pill" href="#menu2"><i class="fa fa-book mr-2"></i> Purchase Details</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link rounded-0" data-toggle="pill" href="#menu3"><i class="fa fa-book mr-2"></i> Study Materials</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link rounded-0" data-toggle="pill" href="#menu4"><i class="fa fa-laptop mr-2"></i> Online Class Link</a>
                                    </li>
                                </ul>
                                <hr>
                                <a class="nav-link" href=""><i class="fa fa-logout mr-2"></i> Log Out</a>
                            </div>
                        </div>
                    </div>


                    <div class="sec1-of-blog col-lg-9">
                        <div class="card border-0 rounded-0 shd1 p-3">
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div id="home" class="container tab-pane active">
                                    <h4 class="text-blue mt-3">Personal Information</h4>
                                    <form name="frmContact" id="frmContact" action="" method="GET" target="#">
                                        <div class="row">
                                            <div class="col-12 mt-4 pt-2"><h5>Profile Update</h5></div>
                                            <div class="form-group col-md-3 mt-4">
                                                <div class="border border-muted rounded bg-light p-2">
                                                    <input type="text" placeholder="Name" name="txtName" id="txtName" class="form-control bg-light border-0 shadow-none">
                                                </div>
                                                <span id="Nameerror" style="color: red;"></span>
                                            </div>
                                            <div class="form-group col-md-3 mt-4">
                                                <div class="border border-muted rounded bg-light p-2">
                                                    <input type="text" placeholder="Phone" name="txtPhone" id="txtPhone" class="form-control bg-light border-0 shadow-none">
                                                </div>
                                                <span id="Phoneerror" style="color: red;"></span>
                                            </div>
                                            <div class="form-group col-md-3 mt-4">
                                                <div class="border border-muted rounded bg-light p-2">
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input" id="customFile">
                                                        <label class="custom-file-label" for="customFile">Choose file</label>
                                                    </div>
                                                </div>
                                                <span id="Phoneerror" style="color: red;"></span>
                                            </div>
                                            <div class="form-group col-md-3 mt-4">
                                                <input type="submit" value="Update" class="btn btn btns9 rounded-pill py-3 px-5">
                                            </div>
                                        </div>
                                        <div class="row mt-4">
                                            <div class="col-12 mt-5"><h5>Email Address</h5></div>
                                            <div class="form-group col-md-4 mt-4">
                                                <div class="border border-muted rounded bg-light p-2">
                                                <input type="email" placeholder="Email" name="txtEmail" id="txtEmail" class="form-control bg-light border-0 shadow-none">
                                                </div>
                                                <span id="Emailerror" style="color: red;"></span>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div id="menu1" class="container tab-pane fade">
                                    <h4 class="text-blue mt-3">Change Password</h4>
                                    <form name="frmContact" id="frmContact" action="" method="GET" target="#">
                                        <div class="row">
                                            <div class="form-group col-md-6 mt-4">
                                                <div class="border border-muted rounded bg-light p-2">
                                                    <input type="password" placeholder="Password" name="txtPassword" id="txtPassword" class="form-control bg-light border-0 shadow-none">
                                                </div>
                                                <span id="Passworderror" style="color: red;"></span>
                                            </div>
                                            <div class="form-group col-md-6 mt-4">
                                                <div class="border border-muted rounded bg-light p-2">
                                                    <input type="password" placeholder="Retype New Password" name="txtNewPassword" id="txtNewPassword" class="form-control bg-light border-0 shadow-none">
                                                </div>
                                                <span id="NewPassworderror" style="color: red;"></span>
                                            </div>
                                            <div class="form-group col-12 mt-4">
                                                <input type="submit" value="Change Password" class="btn btn btns9 rounded-pill py-3 px-5">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div id="menu2" class="container tab-pane fade">
                                    <h4 class="text-blue mt-3">Purchase Details</h4>
                                    <div class="table-responsive mt-4">
                                        <table class="table table-striped table-hover">
                                            <thead class="bg-blue1 text-white">
                                                <tr>
                                                    <th>Order No</th>
                                                    <th>Course</th>
                                                    <th>Date</th>
                                                    <th>Coupon Code</th>
                                                    <th>Real Price</th>
                                                    <th>Offer Price</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>John</td>
                                                <td>Doe</td>
                                                <td>john@</td>
                                                <td>John</td>
                                                <td>Doe</td>
                                                <td>john@example.com</td>
                                            </tr>
                                            <tr>
                                                <td>Mary</td>
                                                <td>Moe</td>
                                                <td>mary@</td>
                                                <td>John</td>
                                                <td>Doe</td>
                                                <td>john@example.com</td>
                                            </tr>
                                            <tr>
                                                <td>July</td>
                                                <td>Dooley</td>
                                                <td>july@</td>
                                                <td>John</td>
                                                <td>Doe</td>
                                                <td>john@example.com</td>
                                            </tr>
                                            <tr>
                                                <td>July</td>
                                                <td>Dooley</td>
                                                <td>july@</td>
                                                <td>John</td>
                                                <td>Doe</td>
                                                <td>john@example.com</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div id="menu3" class="container tab-pane fade">
                                <h4 class="text-blue mt-3">Study Materials</h4>
                                    <div class="table-responsive mt-4">
                                        <table class="table table-striped table-hover">
                                            <thead class="bg-blue1 text-white">
                                                <tr>
                                                    <th>Course</th>
                                                    <th>View Details</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>John</td>
                                                <td>Doe</td>
                                            </tr>
                                            <tr>
                                                <td>Mary</td>
                                                <td>Moe</td>
                                            </tr>
                                            <tr>
                                                <td>July</td>
                                                <td>Dooley</td>
                                            </tr>
                                            <tr>
                                                <td>July</td>
                                                <td>Dooley</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div id="menu4" class="container tab-pane fade">
                                <h4 class="text-blue mt-3">Online Class Link</h4>
                                    <div class="table-responsive mt-4">
                                        <table class="table table-striped table-hover">
                                            <thead class="bg-blue1 text-white">
                                                <tr>
                                                    <th>Course</th>
                                                    <th>Meeting URL</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>John</td>
                                                <td>Doe</td>
                                            </tr>
                                            <tr>
                                                <td>Mary</td>
                                                <td>Moe</td>
                                            </tr>
                                            <tr>
                                                <td>July</td>
                                                <td>Dooley</td>
                                            </tr>
                                            <tr>
                                                <td>July</td>
                                                <td>Dooley</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>    

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

<script>
// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>

</body>
</html>