<?php $page= "about";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- plus-minus-button -->    
<link href="assets/plus-minus-buttons/style.css" rel="stylesheet" type="text/css"> 
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- section1 -->
        <section class="section1 bg-sec4">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container py-5">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white">CART</h1>
                        <p class="mt-3 small">
                            <a class="clr-red mr-2 text-white text-decoration-none small" href="index.php">HOME</a> 
                            <span class="text-white small"> / &nbsp; CART</span>
                        </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- section1-of-cart -->
        <section class="section1-of-cart mb-5 mt-5 pt-5 text-secondary">
            <div class="container">
                <div class="row">     
                    <div class="col-12 col-md-12 col-lg-12">
                        
                        <div class="container text-center">
                            <div class="table-responsive">   
                                <table class="table table-bordered table-hover mb-0">
            
                                    <thead>
                                        <tr>
                                            <th>Images</th>
                                            <th>Product</th>  
                                            <th>Unit Price</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                            <th>Remove</th>  
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="w-25"><img class="w-50" src="assets/image/book1.png"></td>
                                            <td class="pt-4"><br> Bakix Furniture</td>  
                                            <td class="pt-4"><br> $130.00</td>
                                            <td class="pt-3"><br>
                                                <span>
                                                    <form class="form-inline form">
                                                        <input class="input" type="number" min="1" max="100" value="1" />
                                                    </form>
                                                </span> 
                                            </td>
                                            <td class="pt-4"><br> $130.00</td>
                                            <td class="pt-4"><br> <i class="fa fa-times"></i></td>    
                                        </tr>
                                        <tr>
                                            <td class="w-25"><img class="w-50" src="assets/image/book2.png"></td>
                                            <td class="pt-4"><br> Bakix Furniture</td>  
                                            <td class="pt-4"><br> $130.00</td>
                                            <td class="pt-3"><br>
                                                <span>
                                                    <form class="form-inline form">
                                                        <input class="input" type="number" min="1" max="100" value="1" />
                                                    </form>
                                                </span>   
                                            </td>
                                            <td class="pt-4"><br> $130.00</td>
                                            <td class="pt-4"><br> <i class="fa fa-times"></i></td>    
                                        </tr>   
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        
            <!-- section2-of-cart -->
            <section class="section2-of-cart  mb-5 text-center text-md-left">
            <div class="container">
                <div class="row align-items-center mt-5">
                    <div class="col-12 col-lg-6 text-center text-lg-left btn-group">
                        <input type="text" class="form-control rounded-pill p-4 h-25" placeholder="Coupon Code" name="contactName" id="contactName">    
                        <a class="btn btn btns8 rounded-pill px-5 pt-4 ml-2" href="#"><nobr>APPLY COUPON</nobr></a>
                    </div>   
                    <div class="col-12 col-lg-6 mt-4 mt-sm-0 text-center text-lg-right">
                        <form class="ml-auto"> 
                            <a class="btn btn btns8 rounded-pill px-5 py-4" href="#">UPDATE CART</a>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- section3-of-cart -->
        <section class="section3-of-cart text-center mb-5 text-lg-left">
            <div class="container">
                <div class="row mt-5">
                    <div class="col-12 col-lg-6"></div>
                    <div class="col-12 col-lg-6">
                        <h4 class="font-weight-bold">Cart Totals</h4>
                        <ul class="list-group text-grey mt-4">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                            Inbox
                            <span class="">$250.00</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                            Ads
                            <span class="">$250.00</span>
                            </li>
                        </ul>
                        <a class="btn btn btns9 rounded-pill px-5 py-4 mt-4" href="#">PROCEED TO CHECKOUT</a>
                        </div>
                    </div>
                </div>
            </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

<script>
    //<!-- plus-minus-button -->    
    (function($) {
      $.fn.spinner = function() {
          this.each(function() {
              var el = $(this);

              // add elements
              el.wrap('<span class="spinner"></span>');     
              el.before('<span class="sub">-</span>');
              el.after('<span class="add">+</span>');

              // substract
              el.parent().on('click', '.sub', function () {
                  if (el.val() > parseInt(el.attr('min')))
                      el.val( function(i, oldval) { return --oldval; });
              });

              // increment
              el.parent().on('click', '.add', function () {
                  if (el.val() < parseInt(el.attr('max')))
                      el.val( function(i, oldval) { return ++oldval; });
              });
          });
      };
    })(jQuery);
    $('input[type=number]').spinner();
</script>

</body>
</html>